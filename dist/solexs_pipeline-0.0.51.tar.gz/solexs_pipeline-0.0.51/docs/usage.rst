=====
Usage
=====

To use solexs_pipeline in a project::

    import solexs_pipeline
