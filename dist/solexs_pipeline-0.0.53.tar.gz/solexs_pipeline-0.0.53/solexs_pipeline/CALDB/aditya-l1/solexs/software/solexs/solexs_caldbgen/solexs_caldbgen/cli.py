#####################################################
# @Author: Abhilash Sarwade
# @Date:   2021-10-05 16:24:19
# @email: sarwade@ursc.gov.in
# @File Name: cli.py
# @Project: solexs_caldbgen

# @Last Modified time: 2021-10-05 16:56:13
#####################################################
"""Console script for solexs_caldbgen."""
import sys
import click


@click.command()
def main(args=None):
    """Console script for solexs_caldbgen."""
    click.echo("Replace this message by putting your code into "
               "solexs_caldbgen.cli.main")
    click.echo("See click documentation at https://click.palletsprojects.com/")
    return 0


if __name__ == "__main__":
    sys.exit(main())  # pragma: no cover
