#####################################################
# @Author: Abhilash Sarwade
# @Date:   2021-10-04 11:12:46
# @email: sarwade@ursc.gov.in
# @File Name: calc_arf.py
# @Project: solexs_caldbgen

# @Last Modified time: 2021-10-05 16:40:00
#####################################################

import numpy as np
from xraydb import XrayDB
from . import fits_utils

xdb = XrayDB()

def calc_arf(thickness,ene_in,area):
    th = thickness/1e4

    thick_si = th[0,0]#4.5E-02  # 450um thickness Si
    den_si   = xdb.density('Si')#2.329  # density in gm/cm3

    thick_be = th[1,0]#8E-04 # 8um thichness Be
    den_be   = xdb.density('Be')#1.85   # density in gm/cm3

    thick_al = th[2,0]#1E-05  # 1000 A thickness of Al
    den_al   = xdb.density('Al')#2.7    # density of Al

    thick_kapton = th[4,0]#0#6E-04  # 6um thickness of Kapton (C22H10N2O5)
    den_kapton   = 1.43   # density of Kapton

    thick_si_dead = th[3,0]#1E-06 # 100 A thichness of Si dead layer

    lin_e = np.mean(ene_in,axis=1)
    energy = lin_e

    #
    tot_si = xdb.mu_elam('Si',energy*1000)
    tot_be = xdb.mu_elam('Be',energy*1000)
    tot_al = xdb.mu_elam('Al',energy*1000)
    tot_kapton = 1


    #
    eff_frac = (1-np.exp(-thick_si*den_si*tot_si))*(np.exp(-thick_be*den_be*tot_be))*(np.exp(-thick_al*den_al*tot_al))*(np.exp(-thick_kapton*den_kapton*tot_kapton))*(np.exp(-thick_si_dead*den_si*tot_si)) 
    eff_area = eff_frac*area
    return eff_area

def write_arf(ene_in,eff_area,arf_file):
    fits_arf = fits_utils.ARF(ene_in,eff_area,'Aditya-L1','SoLEXS')
    fits_arf.writeto(arf_file)