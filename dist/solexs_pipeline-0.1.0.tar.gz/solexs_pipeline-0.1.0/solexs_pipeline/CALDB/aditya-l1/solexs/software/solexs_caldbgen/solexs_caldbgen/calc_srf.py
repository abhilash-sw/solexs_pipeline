#####################################################
# @Author: Abhilash Sarwade
# @Date:   2021-10-04 11:20:41
# @email: sarwade@ursc.gov.in
# @File Name: calc_srf.py
# @Project: solexs_caldbgen

# @Last Modified time: 2024-01-25 07:25:03 am
#####################################################

from xraydb import XrayDB
import numpy as np
from . import fits_utils
from scipy.integrate import quad 
from numba import njit, prange, jit
from scipy.special import erf, erfc

xdb = XrayDB()

si_ka = 1739 #eV
mu_si = xdb.mu_elam('Si',si_ka)

@njit(parallel=True)
def gaussian(x, center, sigma):
    width = sigma
    height = 1/sigma/np.sqrt(2*np.pi)
    return height*np.exp(-(x - center)**2/(2*width**2))

@jit(parallel=True)
def gaussian_prob(sigma,enes_out): # sigma in energy, enes_out 2*n
    center = np.mean(enes_out[:,0])#,axis=0)[0]
    prob = np.zeros(len(enes_out))
    for i in prange(len(enes_out)):
        prob[i] = quad(gaussian,enes_out[i,0],enes_out[i,1],args=(center,sigma))[0]

    prob = prob/np.sum(prob)

    return prob

def get_xdb_mu(element,ene_in): #keV
    enes = ene_in #np.loadtxt('../../ebounds/ebounds_in/energy_bins_in.dat')
    lin_e = np.mean(enes,axis=1)    
    mu_arr = []
    for energy in lin_e:
        mu_arr.append(xdb.mu_elam(element,energy))
    mu_arr = np.array(mu_arr)
    return mu_arr

@njit(parallel=True)
def calc_xsm_sigma(energy,a=3528.9,b=299.04,c=9.41): #energy in keV
    sigma = np.sqrt(a+b*energy+c*energy**2)
    return sigma*1e-3 #keV


@jit(parallel=True)
def calc_gaussian_srf(ene_out_512,ene_in,electronic_sigma,fano,mu_arr):
    enes_out = ene_out_512#np.loadtxt('../../ebounds/ebounds_out/energy_bins_512_out.dat')
    enes_out_max = np.max(enes_out)

    n_ch = len(enes_out)#512
    del_e =enes_out[0,1] - enes_out[0,0] #60e-3 #keV (assuming uniform bin widths)


    #Ebounds In (Model)
    enes = ene_in #np.loadtxt('../../ebounds/ebounds_in/energy_bins_in.dat')
    lin_e = (enes[:,0]+enes[:,1])/2#np.mean(enes,axis=1)


    spec = np.zeros((len(lin_e),n_ch))

    ch = np.arange(n_ch)


    # electronic_sigma = np.loadtxt('../../electronic_noise/electronic_noise.txt')*1#0.050 #0.15212#0.050 #keV
    # fano = np.loadtxt('../../electronic_noise/fano.txt')*1#0.114
    epsi = 3.66e-3

    # srf generation
    for iii in prange(len(lin_e)):#, E_ph in enumerate(lin_e):
        E_ph = lin_e[iii]
        if E_ph>enes_out_max:
            continue
        spectrum_main = np.zeros(n_ch)
        spectrum_esc = np.zeros(n_ch)

        ch_ph = int(E_ph/del_e)
        #if ch_ph>n_ch:
        #    continue

        ## For escape peak
        if E_ph*1e3 > si_ka:
        
            
            mu_1 = mu_arr[iii]#xdb.mu_elam('Si',E_ph*1000)
            epsi_esc = 1/2*(1 - mu_si/mu_1*np.log(1+ mu_1/mu_si))

            E_esc = E_ph - si_ka/1000
            ch_esc = int(E_esc/del_e)


            k = 0.035*epsi_esc/(1 - 0.035*epsi_esc)


            n_photo = 1 #- n_shelf_front
            n_photo1 = n_photo/(1+k)
            n_esc = n_photo1*k
            n_photo = n_photo1

            spectrum_main[ch_ph] = n_photo #main channel 
            spectrum_esc[ch_esc] = n_esc #escape peak

            ## convolution
            sigma_main = np.sqrt(electronic_sigma**2 + fano*epsi*E_ph)#/del_e # sigma in channels (remove del_e)
            sigma_esc = np.sqrt(electronic_sigma**2 + fano*epsi*E_esc)#/del_e # sigma in channels (remove del_e)

            # sigma_main = calc_xsm_sigma(E_ph)
            # sigma_esc = calc_xsm_sigma(E_esc)

            # g_main = gaussian(ch,len(ch)/2,sigma_main)
            # g_esc = gaussian(ch,len(ch)/2,sigma_esc)
            prob_main = gaussian_prob(sigma_main,enes_out)
            prob_esc = gaussian_prob(sigma_esc,enes_out)

            conv_spectrum_main = np.convolve(spectrum_main,prob_main,mode='same')
            conv_spectrum_esc = np.convolve(spectrum_esc,prob_esc,mode='same')
     
            conv_spectrum_full = conv_spectrum_main + conv_spectrum_esc

            conv_spectrum_full[conv_spectrum_full<1e-16] = 0
            spec[iii,:] = conv_spectrum_full

        else:
            n_photo = 1
            spectrum_main[ch_ph] = n_photo #main channel 
            ## convolution
            sigma_main = np.sqrt(electronic_sigma**2 + fano*epsi*E_ph)#/del_e # sigma in channels
            g_main = gaussian(ch,len(ch)/2,sigma_main)
            conv_spectrum_main = np.convolve(spectrum_main,g_main,mode='same')
            conv_spectrum_full = conv_spectrum_main
            conv_spectrum_full[conv_spectrum_full<1e-16] = 0
            spec[iii,:] = conv_spectrum_full


    spec_340 = np.zeros((len(lin_e),340))

    spec_340[:,:168] = spec[:,:168]

    ## DOESN"T WORK. DO NOT USE spec_340
    j = 168
    for i in range(168,340):
        spec_340[:,i] = np.sum(spec[:,j:j+2],axis=1)
        j = j+2    

    return spec, spec_340


def calc_hypermet_srf(ene_out_512,ene_in,esc_peak_int_arr): #based on XSM cal
    #XSM values
    a = 3528.9
    b = 299.04
    c = 9.41
    i_tail0 = 6.21e-3
    gamma = 4.63
    beta = 0.5
    i_shelf = 1e-4
    alpha = 0.3

    enes_out = ene_out_512#np.loadtxt('../../ebounds/ebounds_out/energy_bins_512_out.dat')
    enes_out_max = np.max(enes_out)
    enes_out_mean = (enes_out[:,0]+enes_out[:,1])/2

    n_ch = len(enes_out)#512
    del_e =enes_out[0,1] - enes_out[0,0] #60e-3 #keV (assuming uniform bin widths)


    #Ebounds In (Model)
    enes = ene_in #np.loadtxt('../../ebounds/ebounds_in/energy_bins_in.dat')
    lin_e = (enes[:,0]+enes[:,1])/2#np.mean(enes,axis=1)


    spec = np.zeros((len(lin_e),n_ch))

    ch = np.arange(n_ch)


    # electronic_sigma = np.loadtxt('../../electronic_noise/electronic_noise.txt')*1#0.050 #0.15212#0.050 #keV
    # fano = np.loadtxt('../../electronic_noise/fano.txt')*1#0.114
    epsi = 3.66e-3    

    for iii in prange(len(lin_e)):#, E_ph in enumerate(lin_e):
        E_ph = lin_e[iii]
        if E_ph>enes_out_max:
            continue
        spectrum_p1 = np.zeros(n_ch)
        spectrum_p2 = np.zeros(n_ch)
        spectrum_t = np.zeros(n_ch)
        spectrum_s = np.zeros(n_ch)

        ch_ph = int(E_ph/del_e)
        #if ch_ph>n_ch:
        #    continue

        sigma_main = calc_xsm_sigma(E_ph,a,b,c,)#/del_e
        
        i_tail = i_tail0*(E_ph/15)**gamma
        i_esc = 0

        spectrum_p1 = gaussian(enes_out_mean,E_ph,sigma_main)
        
        spectrum_t = i_tail*np.exp((enes_out_mean-E_ph)/beta)*erfc((enes_out_mean-E_ph)/np.sqrt(2)/sigma_main + np.sqrt(2)*sigma_main/2/beta)

        spectrum_s = i_shelf*(enes_out_mean/10)**(-1*alpha)*(erf((enes_out_mean - si_ka/1000)/np.sqrt(2)/sigma_main) + 2)
        spectrum_s[enes_out_mean>E_ph]=0

        ## For escape peak
        if E_ph*1e3 > si_ka:
        
            
            # mu_1 = mu_arr[iii]#xdb.mu_elam('Si',E_ph*1000)
            # epsi_esc = 1/2*(1 - mu_si/mu_1*np.log(1+ mu_1/mu_si))

            E_esc = E_ph - si_ka/1000
            ch_esc = int(E_esc/del_e)


            # k = 0.035*epsi_esc/(1 - 0.035*epsi_esc)
            i_esc = np.interp(E_ph,esc_peak_int_arr[:,0],esc_peak_int_arr[:,1])
            
            sigma_esc = calc_xsm_sigma(E_esc,a,b,c)#/del_e

            
            spectrum_p2 = i_esc*gaussian(enes_out_mean,E_esc,sigma_esc)


        spectrum_full = spectrum_p1 + spectrum_p2 + spectrum_t + spectrum_s
        spectrum_full = spectrum_full/np.sum(spectrum_full)
        spec[iii,:] = spectrum_full

    return spec

def srf2rsp(srf,arf): #assuming ene_in is same for both
    rsp = np.zeros(srf.shape)
    for i in range(srf.shape[0]):
        rsp[i,:] = srf[i,:]*arf[i]

    return rsp


def write_rsp(ene_in,ene_out_340,rsp,rsp_file): 
    fits_rsp = fits_utils.RSP(ene_in,ene_out_340,rsp.T,'Aditya-L1','SoLEXS')
    fits_rsp.writeto(rsp_file)

def write_srf(ene_in,ene_out_340,rmf,rmf_file):
    fits_rmf = fits_utils.RMF(ene_in,ene_out_340,rmf.T,'Aditya-L1','SoLEXS')
    fits_rmf.writeto(rmf_file)