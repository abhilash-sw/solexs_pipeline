=====
Usage
=====

To use solexs_caldbgen in a project::

    import solexs_caldbgen
