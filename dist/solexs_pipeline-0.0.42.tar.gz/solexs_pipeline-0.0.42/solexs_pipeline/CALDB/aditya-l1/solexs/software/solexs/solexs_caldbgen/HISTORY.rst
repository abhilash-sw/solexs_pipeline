=======
History
=======

0.0.1 (2021-10-05)
------------------

* First release on PyPI.
