===============
solexs_caldbgen
===============






CALDB generation software for payload SoLEXS on Aditya-L1



Features
--------

* TODO

1. Add Primary Header Keywords

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
