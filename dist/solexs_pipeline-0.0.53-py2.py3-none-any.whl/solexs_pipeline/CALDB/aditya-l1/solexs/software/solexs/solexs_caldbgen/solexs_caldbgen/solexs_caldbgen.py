#####################################################
# @Author: Abhilash Sarwade
# @Date:   2021-10-05 16:24:19
# @email: sarwade@ursc.gov.in
# @File Name: solexs_caldbgen.py
# @Project: solexs_caldbgen

# @Last Modified time: 2021-10-26 14:33:48
#####################################################
"""Main module."""

import numpy as np
from solexs_caldbgen import calc_ene_bins_in, calc_ene_bins_out, calc_arf, write_arf, calc_gaussian_srf, srf2rsp, write_srf, write_rsp, get_xdb_mu, calc_hypermet_srf
import os

CPF_SUBDIRS = ['ebounds','ebounds/ebounds_in','ebounds/ebounds_out','arf','response','response/rmf','response/rsp']


def calc_caldb(BCF_DIR,SDD_number,srf_type='gaussian'):
    SDD_no = str(SDD_number)
    GAIN_FILE = f'{BCF_DIR}/gain/gain.txt'
    THICKNESS_FILE = f'{BCF_DIR}/arf/material_thickness.dat'
    AREA_FILE = f'{BCF_DIR}/aperture_size/SDD{SDD_no}'
    ELE_SIGMA_FILE = f'{BCF_DIR}/electronic_noise/electronic_noise.txt'
    FANO_FILE = f'{BCF_DIR}/electronic_noise/fano.txt'


    gain_data = np.loadtxt(GAIN_FILE,usecols=[1,2])

    gain = gain_data[0,0]
    offset = gain_data[1,0]

    thickness = np.loadtxt(THICKNESS_FILE,usecols=[1,2])

    area = np.loadtxt(AREA_FILE)

    electronic_sigma_data = np.loadtxt(ELE_SIGMA_FILE)*1#0.050 #0.15212#0.050 #keV
    electronic_sigma = electronic_sigma_data[0]
    fano = np.loadtxt(FANO_FILE)*1#0.114

    e_start = 0.5 #keV for ene_in
    e_end = 25 # keV for ene_in
    delta_e = 0.01 #keV for ene_in

    ene_in = calc_ene_bins_in(e_start,e_end,delta_e)

    ene_out, ene_out_512 = calc_ene_bins_out(gain,offset)

    eff_area = calc_arf(thickness,ene_in,area)

    if srf_type=='gaussian':
        mu_arr = get_xdb_mu('Si',ene_in)
        srf_512, srf = calc_gaussian_srf(ene_out_512,ene_in,electronic_sigma,fano,mu_arr)

    if srf_type=='hypermet':
        ESCP_PEAK_FILE = f'{BCF_DIR}/electronic_noise/xsm_escape_peak_intensity.dat'
        esc_peak_int_arr = np.loadtxt(ESCP_PEAK_FILE)
        esc_peak_int_arr[np.isnan(esc_peak_int_arr[:,1]),1] = 0

        srf_512 = calc_hypermet_srf(ene_out_512,ene_in,esc_peak_int_arr)
        srf = np.zeros((len(ene_in),340))

    rsp = srf2rsp(srf,eff_area)
    rsp_512 = srf2rsp(srf_512,eff_area)

    # rsp_hyp = srf2rsp(srf_hyp,eff_area)

    return ene_in, ene_out, ene_out_512, eff_area, srf, srf_512, rsp, rsp_512

def write_caldb(ene_in, ene_out, ene_out_512, eff_area, srf, srf_512, rsp, rsp_512, CPF_DIR, SDD_number):
    SDD_no = str(SDD_number)

    for CPF_SUBDIR in CPF_SUBDIRS:
        os.mkdir(os.path.join(CPF_DIR,CPF_SUBDIR))

    np.savetxt(f'{CPF_DIR}/ebounds/ebounds_in/energy_bins_in.dat',ene_in,fmt='%f\t%f')

    np.savetxt(f'{CPF_DIR}/ebounds/ebounds_out/energy_bins_out.dat',ene_out,fmt='%f\t%f')
    np.savetxt(f'{CPF_DIR}/ebounds/ebounds_out/energy_bins_512_out.dat',ene_out_512,fmt='%f\t%f')

    arf_file = f'{CPF_DIR}/arf/solexs_arf_SDD{SDD_no}.fits'
    write_arf(ene_in,eff_area,arf_file)

    # rsp_file = f'{CPF_DIR}/response/rsp/solexs_gaussian_SDD{SDD_no}.rsp'
    # write_rsp(ene_in,ene_out,rsp,rsp_file)

    # rmf_file = f'{CPF_DIR}/response/rmf/solexs_gaussian_SDD{SDD_no}.rmf'
    # write_srf(ene_in,ene_out,srf,rmf_file)

    rsp_512_file = f'{CPF_DIR}/response/rsp/solexs_gaussian_SDD{SDD_no}_512.rsp'
    write_rsp(ene_in,ene_out_512,rsp_512,rsp_512_file)

    rmf_512_file = f'{CPF_DIR}/response/rmf/solexs_gaussian_SDD{SDD_no}_512.rmf'
    write_srf(ene_in,ene_out_512,srf_512,rmf_512_file)


