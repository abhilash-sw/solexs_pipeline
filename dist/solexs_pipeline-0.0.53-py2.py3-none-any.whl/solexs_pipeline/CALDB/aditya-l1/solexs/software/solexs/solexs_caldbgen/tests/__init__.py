"""Unit test package for solexs_caldbgen."""
