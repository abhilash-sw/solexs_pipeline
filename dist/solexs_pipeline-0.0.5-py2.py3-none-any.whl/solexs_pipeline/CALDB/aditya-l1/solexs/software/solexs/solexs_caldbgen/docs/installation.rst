.. highlight:: shell

============
Installation
============


Stable release
--------------

To install solexs_caldbgen, run this command in your terminal:

.. code-block:: console

    $ pip install solexs_caldbgen

This is the preferred method to install solexs_caldbgen, as it will always install the most recent stable release.

If you don't have `pip`_ installed, this `Python installation guide`_ can guide
you through the process.

.. _pip: https://pip.pypa.io
.. _Python installation guide: http://docs.python-guide.org/en/latest/starting/installation/


From sources
------------

The sources for solexs_caldbgen can be downloaded from the `Github repo`_.

You can either clone the public repository:

.. code-block:: console

    $ git clone git://github.com/abhilash_sw/solexs_caldbgen

Or download the `tarball`_:

.. code-block:: console

    $ curl -OJL https://github.com/abhilash_sw/solexs_caldbgen/tarball/master

Once you have a copy of the source, you can install it with:

.. code-block:: console

    $ python setup.py install


.. _Github repo: https://github.com/abhilash_sw/solexs_caldbgen
.. _tarball: https://github.com/abhilash_sw/solexs_caldbgen/tarball/master
