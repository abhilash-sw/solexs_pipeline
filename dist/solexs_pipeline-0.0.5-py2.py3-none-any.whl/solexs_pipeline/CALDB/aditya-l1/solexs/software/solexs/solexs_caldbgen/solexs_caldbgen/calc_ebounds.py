#####################################################
# @Author: Abhilash Sarwade
# @Date:   2021-10-04 11:17:27
# @email: sarwade@ursc.gov.in
# @File Name: calc_ebounds.py
# @Project: solexs_caldbgen

# @Last Modified time: 2021-10-05 16:39:58
#####################################################

import numpy as np

def calc_ene_bins_in(e_start,e_end,delta_e):
    es = np.arange(e_start,e_end,delta_e)
    ee = es + delta_e

    e = np.vstack((es,ee)).T
    return e

def calc_ene_bins_out(gain,offset):
    delta_e = gain#0.06 #kev for first 168 bins

    es1 = np.arange(168)*delta_e
    ee1 = es1+delta_e

    es2 = ee1[-1]+np.arange(340-168)*delta_e*2
    ee2 = es2+delta_e*2

    es = np.concatenate((es1,es2)) + offset
    ee = np.concatenate((ee1,ee2)) + offset

    ene_out = np.vstack((es,ee)).T

    # np.savetxt('ebounds_out/energy_bins_out.dat',e,fmt='%f\t%f')


    ####### for 512 bins
    es = np.arange(512)*delta_e + offset
    ee = es + delta_e + offset

    ene_out_512 = np.vstack((es,ee)).T

    return ene_out, ene_out_512

