"""Top-level package for solexs_pipeline."""

__author__ = """Abhilash Sarwade"""
__email__ = 'sarwade@ursc.gov.in'
__version__ = '0.0.81'

from .binary_read import read_solexs_binary_data
